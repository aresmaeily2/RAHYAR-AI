package com.rahyarai.app;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.webkit.WebView;

import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * صوت بومی — تشخیص گفتار اندروید (fa-IR/en-US) و خواندن پاسخ با TTS سیستم.
 *
 * قرارداد رویدادها (اندروید → وب، با تزریق به WebView):
 *   rahyar-voice-partial {text}     متن موقت
 *   rahyar-voice-final   {text}     نتیجهٔ قطعی
 *   rahyar-voice-error   {code}     no_match | busy | denied | unavailable | error
 *   rahyar-voice-end                پایان شنود
 *   rahyar-voice-perm    {state}    granted | denied   (پس از دیالوگ مجوز)
 *   rahyar-tts-done                 پایان خواندن
 *
 * حریم خصوصی (مأموریت — بند ۲/۱۲): شنود فقط با لمس دکمهٔ میکروفون آغاز می‌شود؛
 * صدا مستقیماً به سرویس گفتار سیستم‌عامل می‌رود، هیچ‌گاه ذخیره یا به هیچ سروری
 * ارسال نمی‌شود. شنود پس از پایان جمله یا لغو کاربر فوراً تمام می‌شود.
 *
 * یادداشت مجوز: SpeechRecognizer به RECORD_AUDIO نیاز ندارد — فرایند تشخیص
 * توسط سرویس گفتار سیستم انجام می‌شود (قرارداد پلتفرم)؛ ما با این حال مجوز را
 * صریح می‌گیریم تا سرویس‌هایی که باطن آن‌ها در همین فرایند است بدون خطا کار کنند
 * و نمایش وضعیت مجوز در UI ممکن باشد.
 */
public final class VoiceHelper implements RahyarBridge.VoiceDelegate {

    /** JS رویداد — خالص و تست‌پذیر (خروجی باید evaluateJavascript-safe باشد) */
    /**
     * F2-TEST-HOOK (فقط دیباگ): ساخت همین رویداد «نتیجهٔ قطعی شنیدار» برای تزریق
     * فرمان متنی از adb روی شبیه‌ساز بدون میکروفون. مسیر اجرا (پارسر + موتور اجرای
     * app.js) کاملاً واقعی است؛ تنها مرحلهٔ STT کنار گذاشته می‌شود. در بیلد Release
     * هیچ مسیر تزریقی وجود ندارد.
     */
    public static String debugFinalEvent(String text) {
        return eventJs("rahyar-voice-final", "{\"text\":\"" + jsString(text) + "\"}");
    }

    static String eventJs(String name, String detailJson) {
        String d = detailJson == null || detailJson.isEmpty() ? "{}" : detailJson;
        return "try{window.dispatchEvent(new CustomEvent('" + name + "',{detail:" + d + "}))}catch(e){}";
    }

    /** متن امن JS — گریز نقل‌قول و بک‌اسلش و خط جدید */
    static String jsString(String raw) {
        if (raw == null) return "";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < raw.length(); i++) {
            char c = raw.charAt(i);
            if (c == '\\' || c == '"') b.append('\\').append(c);
            else if (c == '\n') b.append("\\n");
            else if (c == '\r') b.append("\\r");
            else if (c == '\'') b.append("\\'");
            else if (c < 0x20) b.append(' ');
            else b.append(c);
        }
        return b.toString();
    }

    private final WebView web;
    private final Activity activity;
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private volatile boolean ttsReady = false;
    private final AtomicBoolean listening = new AtomicBoolean(false);
    private String lastLang = "fa-IR";

    public VoiceHelper(WebView web, Activity activity) {
        this.web = web;
        this.activity = activity;
    }

    // ── مجوز میکروفون (قرارداد VoiceDelegate) ──

    @Override
    public String micState() {
        if (activity == null) return "granted";
        int p = activity.checkSelfPermission(Manifest.permission.RECORD_AUDIO);
        return p == PackageManager.PERMISSION_GRANTED ? "granted"
                : activity.shouldShowRequestPermissionRationale(Manifest.permission.RECORD_AUDIO) ? "denied"
                : "need_request";
    }

    @Override
    public void requestMic() {
        if (activity == null) return;
        activity.requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 4701);
    }

    /** پاسخ دیالوگ مجوز — از onRequestPermissions نتیجهٔ اکتیویتی */
    public void onPermissionResult(boolean granted) {
        web.evaluateJavascript(eventJs("rahyar-voice-perm",
                "{\"state\":\"" + (granted ? "granted" : "denied") + "\"}"), null);
    }

    @Override
    public boolean recognitionAvailable() {
        return SpeechRecognizer.isRecognitionAvailable(web.getContext());
    }

    // ── تشخیص گفتار ──

    @Override
    public void startListening(String langBcp47) {
        if (listening.get()) stopListening();
        if (!SpeechRecognizer.isRecognitionAvailable(web.getContext())) {
            emitError("unavailable");
            emitEnd();
            return;
        }
        lastLang = (langBcp47 == null || langBcp47.isEmpty()) ? "fa-IR" : langBcp47;
        recognizer = SpeechRecognizer.createSpeechRecognizer(web.getContext());
        recognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) { /* آماده */ }
            @Override public void onBeginningOfSpeech() { /* شروع گفتار */ }
            @Override public void onRmsChanged(float rmsdB) { /* سطح صدا — استفاده نمی‌شود */ }
            @Override public void onBufferReceived(byte[] buffer) { /* بافر خام — استفاده نمی‌شود */ }
            @Override public void onPartialResults(Bundle partialResults) {
                String t = firstText(partialResults);
                if (t != null && !t.isEmpty()) {
                    web.evaluateJavascript(eventJs("rahyar-voice-partial", "{\"text\":\"" + jsString(t) + "\"}"), null);
                }
            }
            @Override public void onEvent(int eventType, Bundle params) { /* رویداد جانبی */ }
            @Override public void onEndOfSpeech() { /* پایان گفتار — نتیجه در راه است */ }

            @Override public void onError(int error) {
                listening.set(false);
                switch (error) {
                    case SpeechRecognizer.ERROR_NO_MATCH:
                    case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:
                        emitError("no_match");
                        break;
                    case SpeechRecognizer.ERROR_RECOGNIZER_BUSY:
                        emitError("busy");
                        break;
                    case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:
                        emitError("denied");
                        break;
                    default:
                        emitError("error");
                        break;
                }
                emitEnd();
                destroyRecognizer();
            }

            @Override public void onResults(Bundle results) {
                listening.set(false);
                String t = firstText(results);
                if (t != null && !t.trim().isEmpty()) {
                    web.evaluateJavascript(eventJs("rahyar-voice-final", "{\"text\":\"" + jsString(t.trim()) + "\"}"), null);
                } else {
                    emitError("no_match");
                }
                emitEnd();
                destroyRecognizer();
            }
        });
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lastLang);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, lastLang);
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        listening.set(true);
        try {
            recognizer.startListening(i);
        } catch (Exception e) {
            listening.set(false);
            emitError("error");
            emitEnd();
            destroyRecognizer();
        }
    }

    @Override
    public void stopListening() {
        if (recognizer != null) {
            try { recognizer.stopListening(); } catch (Exception ignored) {}
        }
        listening.set(false);
    }

    private void destroyRecognizer() {
        if (recognizer != null) {
            try { recognizer.destroy(); } catch (Exception ignored) {}
            recognizer = null;
        }
    }

    private static String firstText(Bundle b) {
        if (b == null) return null;
        ArrayList<String> list = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (list == null || list.isEmpty()) return null;
        return list.get(0);
    }

    private void emitError(String code) {
        web.evaluateJavascript(eventJs("rahyar-voice-error", "{\"code\":\"" + jsString(code) + "\"}"), null);
    }

    private void emitEnd() {
        web.evaluateJavascript(eventJs("rahyar-voice-end", null), null);
    }

    // ── خروجی صوتی (TTS) ──

    public void initTts() {
        if (tts != null) return;
        tts = new TextToSpeech(web.getContext(), new TextToSpeech.OnInitListener() {
            @Override public void onInit(int status) {
                ttsReady = (status == TextToSpeech.SUCCESS);
            }
        });
    }

    /** خواندن متن — پایان با رویداد rahyar-tts-done */
    @Override
    public void speak(String text, String langBcp47) {
        if (tts == null) initTts();
        if (tts == null || !ttsReady) {
            // TTS هنوز آماده نیست — یک‌بار دیگر در فراخوان بعدی آماده می‌شود
            emitTtsDone();
            return;
        }
        try {
            Locale l;
            if (langBcp47 != null && langBcp47.contains("-")) {
                String[] p = langBcp47.split("-", 2);
                l = new Locale(p[0], p[1]);
            } else {
                l = new Locale(langBcp47 == null || langBcp47.isEmpty() ? "fa" : langBcp47);
            }
            tts.setLanguage(l);
            String id = "rahyar-tts-" + System.nanoTime();
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String utteranceId) { /* شروع */ }
                @Override public void onDone(String utteranceId) { emitTtsDone(); }
                @Override public void onError(String utteranceId) { emitTtsDone(); }
            });
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, id);
        } catch (Exception e) {
            emitTtsDone();
        }
    }

    @Override
    public void stopSpeaking() {
        if (tts != null) {
            try { tts.stop(); } catch (Exception ignored) {}
        }
        emitTtsDone();
    }

    private void emitTtsDone() {
        web.evaluateJavascript(eventJs("rahyar-tts-done", null), null);
    }

    public void destroy() {
        destroyRecognizer();
        if (tts != null) {
            try { tts.stop(); tts.shutdown(); } catch (Exception ignored) {}
            tts = null;
            ttsReady = false;
        }
    }
}
